package br.com.gotoviagens;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGoToViagensApplicationTests {

	@Test
	void contextLoads() {
	}

}
