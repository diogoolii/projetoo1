package br.org.com.recode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBdMvcSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
