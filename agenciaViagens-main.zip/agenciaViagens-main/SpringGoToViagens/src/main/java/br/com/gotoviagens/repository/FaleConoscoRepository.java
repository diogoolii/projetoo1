package br.com.gotoviagens.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.gotoviagens.model.FaleConosco;

public interface FaleConoscoRepository extends JpaRepository<FaleConosco, Long> {

}
