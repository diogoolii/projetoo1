package br.com.gotoviagens.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.gotoviagens.model.TrabalheConosco;

public interface TrabalheConoscoRepository extends JpaRepository<TrabalheConosco, Long> {

}
