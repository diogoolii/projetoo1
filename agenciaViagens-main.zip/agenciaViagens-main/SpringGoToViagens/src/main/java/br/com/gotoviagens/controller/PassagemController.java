package br.com.gotoviagens.controller;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

//import br.com.gotoviagens.repository.PassagemRepository;

@Controller
public class PassagemController {
	
	//@Autowired
	//private PassagemRepository passagemRepository;


	
	
	
}
